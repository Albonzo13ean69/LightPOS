Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "msedge --app=""" & CreateObject("Scripting.FileSystemObject").GetAbsolutePathName(".") & "\app.html""", 1, False
